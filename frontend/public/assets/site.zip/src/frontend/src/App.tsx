import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  RouterProvider,
  createHashHistory,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import type React from "react";
import AboutSection from "./components/AboutSection";
import DigitalImpactSection from "./components/DigitalImpactSection";
import Footer from "./components/Footer";
import HeroSection from "./components/HeroSection";
import Navigation from "./components/Navigation";
import ProfileSetupModal from "./components/ProfileSetupModal";
import ReunionSection from "./components/ReunionSection";
import StakeholderVoicesSection from "./components/StakeholderVoicesSection";
import SurveySection from "./components/SurveySection";
import VisionPillarsSection from "./components/VisionPillarsSection";
import { LanguageProvider } from "./contexts/LanguageContext";
import GalleryPage from "./pages/GalleryPage";
import SurveyPage from "./pages/SurveyPage";

const queryClient = new QueryClient();

// Home page (all sections)
const HomePage: React.FC = () => (
  <>
    <HeroSection />
    <AboutSection />
    <VisionPillarsSection />
    <ReunionSection />
    <SurveySection />
    <StakeholderVoicesSection />
    <DigitalImpactSection />
  </>
);

// Root layout with Navigation and Footer
const RootLayout: React.FC = () => (
  <LanguageProvider>
    <QueryClientProvider client={queryClient}>
      <div className="overflow-x-hidden">
        <Navigation />
        <main>
          <Outlet />
        </main>
        <Footer />
        <ProfileSetupModal />
      </div>
    </QueryClientProvider>
  </LanguageProvider>
);

// Routes
const rootRoute = createRootRoute({ component: RootLayout });

const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: HomePage,
});

const surveyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/survey",
  component: SurveyPage,
});

const galleryRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/gallery",
  component: GalleryPage,
});

const routeTree = rootRoute.addChildren([homeRoute, surveyRoute, galleryRoute]);

const hashHistory = createHashHistory();
const router = createRouter({ routeTree, history: hashHistory });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

const App: React.FC = () => {
  return <RouterProvider router={router} />;
};

export default App;
